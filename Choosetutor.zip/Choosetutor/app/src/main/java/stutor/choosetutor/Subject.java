package stutor.choosetutor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Subject extends AppCompatActivity {

    public Button but1,but2,but3,but4,but5,but6,but7;
    public void init() {

        but1 = (Button) findViewById(R.id.but1);
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);
                overridePendingTransition(R.transition.animation1,R.transition.animation2);

            }
        });
        /*
        but2 = (Button) findViewById(R.id.but2);
        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);

            }
        });
        but3 = (Button) findViewById(R.id.but3);
        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);

            }
        });
        but4 = (Button) findViewById(R.id.but4);
        but4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);

            }
        });
        but5 = (Button) findViewById(R.id.but5);
        but5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);

            }
        });
        but6 = (Button) findViewById(R.id.but6);
        but6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);

            }
        });
        but7 = (Button) findViewById(R.id.but7);
        but7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Subject.this, Clss.class);

                startActivity(toy);

            }
        });
    */
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject);
        init();
    }
}

