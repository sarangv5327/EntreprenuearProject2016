package stutor.choosetutor;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Typetutor extends AppCompatActivity {

    public Button but1,but2,but3,but4,but5;
    public void init(){

        but1=(Button)findViewById(R.id.but1);
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Typetutor.this,Subjectstudentlevel.class);

                startActivity(toy);
                overridePendingTransition(R.transition.animation1,R.transition.animation2);

            }
        });
        but2 = (Button) findViewById(R.id.but2);
        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Typetutor.this,Subjectstudentlevel.class);

                startActivity(toy);
                overridePendingTransition(R.transition.animation1,R.transition.animation2);

            }
        });
        but3 = (Button) findViewById(R.id.but3);
        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent toy = new Intent(Typetutor.this, Subjectstudentlevel.class);

                startActivity(toy);
                overridePendingTransition(R.transition.animation1,R.transition.animation2);

            }
        });
        but4 = (Button) findViewById(R.id.but4);
        but4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendSMS("9256401245");
            }
        });
        but5 = (Button) findViewById(R.id.but5);
        but5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://preview.c9users.io/jameswang1279/entrepreneur_project2016/proftutor.html?_c9_id=livepreview3&_c9_host=https://ide.c9.io"));
                startActivity(intent);
                overridePendingTransition(R.transition.animation1,R.transition.animation2);
            }
        });
    }

        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_typetutor);
            init();
    }
    protected void sendSMS(String x) {
        Log.i("Send SMS", "");
        Intent smsIntent = new Intent(Intent.ACTION_VIEW);

        smsIntent.setData(Uri.parse("smsto:"));
        smsIntent.setType("vnd.android-dir/mms-sms");
        smsIntent.putExtra("address"  , x);
        smsIntent.putExtra("sms_body"  , "Can you tutor me in the HUB?");

        try {
            startActivity(smsIntent);
            overridePendingTransition(R.transition.animation1,R.transition.animation2);
            finish();
            Log.i("Finished sending SMS...", "");
        }
        catch (android.content.ActivityNotFoundException ex) {
            Log.i("Error","");
        }
    }

}
