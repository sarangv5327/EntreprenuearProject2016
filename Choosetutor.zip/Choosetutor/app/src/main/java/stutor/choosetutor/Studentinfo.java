package stutor.choosetutor;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Studentinfo extends AppCompatActivity {


    public Button but1,but2,but3,but4;
    public void init(){
        but1 = (Button) findViewById(R.id.but1);
        but1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendSMS("9256408859");
            }
        });
        but2 = (Button) findViewById(R.id.but2);
        but2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://hangouts.google.com/hangouts/_/yqr4hvkgqzajzk2uhilvut35hie?authuser=0&hl=en"));
                startActivity(intent);
                overridePendingTransition(R.transition.animation1,R.transition.animation2);
                
          }
        });
        but3 = (Button) findViewById(R.id.but3);
        but3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendSMSM("9254870495");
            }
        });
        but4 = (Button) findViewById(R.id.but4);
        but4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.i("hub"," ");
            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentinfo);
        init();
    }

    protected void sendSMS(String x) {
        Log.i("Send SMS", "");
        Intent smsIntent = new Intent(Intent.ACTION_VIEW);

        smsIntent.setData(Uri.parse("smsto:"));
        smsIntent.setType("vnd.android-dir/mms-sms");
        smsIntent.putExtra("address"  , x);
        smsIntent.putExtra("sms_body"  , "Can you stutor me?");

        try {
            startActivity(smsIntent);
            overridePendingTransition(R.transition.animation1,R.transition.animation2);
            finish();
            Log.i("Finished sending SMS...", "");
        }
        catch (android.content.ActivityNotFoundException ex) {
            Log.i("Error","");
        }
    }
    protected void sendSMSM(String x) {
        Log.i("Send SMS", "");
        Intent smsIntent = new Intent(Intent.ACTION_VIEW);

        smsIntent.setData(Uri.parse("smsto:"));
        smsIntent.setType("vnd.android-dir/mms-sms");
        smsIntent.putExtra("address"  , x);
        smsIntent.putExtra("sms_body"  , "Can you stutor me via text?");

        try {
            startActivity(smsIntent);
            overridePendingTransition(R.transition.animation1,R.transition.animation2);
            finish();
            Log.i("Finished sending SMS...", "Can you stutor me via text?");
        }
        catch (android.content.ActivityNotFoundException ex) {
            Log.i("Error","");
        }
    }
}